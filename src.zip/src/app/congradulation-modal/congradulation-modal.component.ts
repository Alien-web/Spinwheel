import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
    selector: 'app-congratulation-modal',
    templateUrl: './congradulation-modal.component.html',
    styleUrls: ['./congradulation-modal.component.css']
})
export class CongradulationModalComponent {
    @Input()
    winner!: string; // The winner player number
    showModal = false;
    @Output() closeEvent = new EventEmitter<boolean>();

    openModal(playerNumber: string) {
        this.winner = playerNumber;
        this.showModal = true;
    }

    okModal() {
        this.showModal = false;
        this.closeEvent.emit(true);
    }

}