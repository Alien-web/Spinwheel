import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { WinnerModalComponent } from '../winner-modal/winner-modal.component';

@Component({
    selector: 'app-instruction-modal',
    templateUrl: './instruction-modal.component.html',
    styleUrls: ['./instruction-modal.component.css']
})
export class InstructionModalComponent  {
    showInstruction:boolean=true;
    @Output() closeEvent = new EventEmitter<boolean>();

    constructor() { }
    closeModal() {
        this.showInstruction=false;
    }
    openModal() {
        this.showInstruction=true;
    }
    spin(){
        this.closeEvent.emit(true);
    }
}