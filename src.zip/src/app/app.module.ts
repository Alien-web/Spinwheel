import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CongradulationModalComponent } from './congradulation-modal/congradulation-modal.component';
import { SpinWheelComponent } from './spin-wheel/spin-wheel.component';
import { QuestionModalComponent } from './question-modal/question-modal.component';
import { WinnerModalComponent } from './winner-modal/winner-modal.component';
import { InstructionModalComponent } from './instruction-modal/instruction-modal.component';
import { NgxWheelModule } from 'ngx-wheel';

@NgModule({
  declarations: [
    AppComponent,
    CongradulationModalComponent,
    SpinWheelComponent,
    QuestionModalComponent,
    WinnerModalComponent,
    InstructionModalComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgxWheelModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
