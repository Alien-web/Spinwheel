import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { WinnerModalComponent } from '../winner-modal/winner-modal.component';

@Component({
    selector: 'app-question-modal',
    templateUrl: './question-modal.component.html',
    styleUrls: ['./question-modal.component.css']
})
export class QuestionModalComponent  {
    @Input() stallNumber:number=0;
    @ViewChild(WinnerModalComponent)
    winnerModal!: WinnerModalComponent;
    answer:number=0;
    cmmi: { question: string, options: string[],answer:number }[] =[     
            { question: 'What does CMMI stand for?', options: ['Continuous Measurement and Monitoring Integration','Capability Maturity Model Integration','Continuous Management and Methodology Integration','Continuous Metrics and Measurement Integration'] ,answer:1},
            { question: 'Which CMMI process area addresses project planning, monitoring, and control?', options: ['Configuration Management','Risk Management','Project Management','Requirements Development'] ,answer:2},
            { question: 'What is process excellence?', options: ['Implementing processes without any improvements','Continuously improving and optimizing processes','Ignoring processes and focusing only on outcomes','None of the above'] ,answer:1},
            { question: 'Which IT quality management approach focuses on reducing defects and improving quality through statistical methods and data analysis?', options: ['Lean','Six Sigma','Scrum','Kanban'] ,answer:1},
            { question: 'Which CMMI maturity level signifies that an organization processes are managed and controlled, but not yet fully documented or standardized?', options: ['Level 2 - Managed','Level 3 - Defined','Level 4 - Quantitatively Managed','Level 5 - Optimizing'] ,answer:0}
          ];
      det: { question: string, options: string[],answer:number }[] = [
        {question: 'How does a generative AI create art?', options: ['By painting with pixels', 'By ordering art supplies online', 'By telling funny jokes to inspire artists', 'By casting a magic spell'], answer: 0},
        {question: 'How does a generative AI stay cool in the summer?', options: ['By overclocking its CPU', 'By writing code for air conditioning systems', 'By generating virtual ice cream', 'By wearing a binary sunhat'], answer: 2},
        {question: 'Why was the computer cold?', options: ['It left its Windows open!', 'It had a bad case of the Java viruses!', 'It couldnt find its CAPS-lock!', 'It was in a drafty algorithm!'] ,answer: 0},       
        {question: 'I have keys but open no locks. I have space but no room. You can enter, but you cant go inside. What am I?', options: ['A keyboard', 'A book', 'A car', 'A treasure chest'], answer: 0},
        {question: 'Which among these are not a key capability of DET Team?', options: ['Generative AI', 'Machine/Deep Learning', 'Conversational AI', 'UX Designing'], answer: 3},
        {question: 'Which AI technology can be used to validate photographs?', options: ['Natural Language Processing', 'Computer Vision', 'Predictive Analytics', 'Reinforcement Learning'], answer: 2},
        {question: 'Which among these DET Accelerators can be used for validating various documents?', options: ['Knowledge Mining', 'Document Intelligence', 'Cyber Genie', 'Policy Genie'], answer: 2},
        {question: 'What is the full form for DET Team?', options: ['Digital & Emerging Technology', 'Development & Engineering Technology', 'Data Engineering Technology', 'Design Engineering & Testing'], answer: 0} 
        ] ;   
      cbs: { question: string, options: string[],answer:number }[] = [
        { question: '------------------ refers to the technology ecosystem within EY, connecting over 86,000+ people driving technology and data enabled business transformation for EY and for clients.', options: ['EY@Technology','jj','e','r'] ,answer:1},
        { question: 'cbsq1---------------------------------------------------------------------------------------------------------------------------------------------------------------------------', options: ['h','h','e','r'] ,answer:0},
        { question: 'cbsq2---------------------------------------------------------------------------------------------------------------------------------------------------------------------------', options: ['u','y','e','r'] ,answer:2},
        { question: 'cbsq3---------------------------------------------------------------------------------------------------------------------------------------------------------------------------', options: ['y','b','e','r'] ,answer:3},
        { question: 'cbsq4---------------------------------------------------------------------------------------------------------------------------------------------------------------------------', options: ['r','n','e','r'] ,answer:0}
      ];
      devops: { question: string, options: string[],answer:number }[] = [
        { question: 'Which Azure DevOps service is used for tracking and managing work items?',options: ['Azure Boards','Azure Repos','Azure Pipelines','Azure Artifacts'], answer: 0},
        { question: 'Which of the following is a valid trigger for an Azure Pipeline?',options: ['Manual trigger','Timer trigger','Source code commit trigger','All of the above'],answer: 3},
        { question: 'What is the primary purpose of Azure Pipelines?',options: ['Code collaboration and version control','Continuous integration and delivery','Infrastructure provisioning and management','Application monitoring and logging'],answer: 1},
        { question: 'Which of the following is NOT a component of Azure DevOps? ', options: ['Azure Boards','Azure Repos','Azure Pipelines','Azure Functions'], answer: 3},
        { question: 'Which of the following tools are not used for Continuous Deployment?',options: ['Azure Pipelines for Deployment','Jenkins','TeamCity','Jasmine'],answer: 3},
        { question: '........... is a source code management tool',options: ['Maven','Jenkins','Git','Hudson'],answer: 2},
        { question: 'What are the key components of DevOps?',options: ['Continuous Integration','Continuous Testing','Continuous Delivery & Monitoring','All of the above'], answer: 3},
        { question: 'Which of the following statement best describes the goal of DevOps?',options: ['Establish an environment to release more reliable applications faster','Estalish an environment where the release of applications is valued more than its quality','Establish an environment where application development performs all the operation tasks','Establish an environment where change management does not control application releases'], answer: 0},
        { question: 'What is the full form of Devops?', options: ['Development And Operations','Digital and Operations','Drive and Operations','None of the above'], answer: 0}
      ];
      luminaLeap: { question: string, options: string[],answer:number }[] = [
        { question: 'luminaLeapq1---------------------------------------------------------------------------------------------------------------------------------------------------------------------------', options: ['hg','jj','e','r'] ,answer:1},
        { question: 'luminaLeapq2---------------------------------------------------------------------------------------------------------------------------------------------------------------------------', options: ['h','h','e','r'] ,answer:0},
        { question: 'luminaLeapq3---------------------------------------------------------------------------------------------------------------------------------------------------------------------------', options: ['u','y','e','r'] ,answer:2},
        { question: 'luminaLeapq4---------------------------------------------------------------------------------------------------------------------------------------------------------------------------', options: ['y','b','e','r'] ,answer:3},
        { question: 'luminaLeapq5---------------------------------------------------------------------------------------------------------------------------------------------------------------------------', options: ['r','n','e','r'] ,answer:0}
      ];
    showModal = false;
    randomValue:number=1;
    question!: { question: string; options: string[]; answer: number; };
    @Output() closeEvent = new EventEmitter<boolean>();

    constructor() { }
    openModal(playerNumber: number) {
        this.stallNumber = playerNumber;
        this.showModal = true;
        switch(this.stallNumber){
            case 1:this.randomValue=Math.floor(Math.random() * 5) ;
            this.question=this.cmmi[this.randomValue];
            break;
            case 2:this.randomValue=Math.floor(Math.random() * 8) ;
            this.question=this.det[this.randomValue];
            break;
            case 4:this.randomValue=Math.floor(Math.random() * 5);
            this.question=this.cbs[this.randomValue];
            break;
            case 5:this.randomValue=Math.floor(Math.random() * 9) ;
            this.question=this.devops[this.randomValue];
            break;
            case 3:this.randomValue=Math.floor(Math.random() * 5) ;
            this.question=this.luminaLeap[this.randomValue];
            break;
            default:break;
    }  
    }
    click(value:number) {
        this.answer=value;
    }
    Submit(){
        this.showModal = false;
        let isWinner=this.answer==this.question.answer
        this.winnerModal.openModal(isWinner);
    }
    winnerClose(){
        this.closeEvent.emit(true);
    }
}