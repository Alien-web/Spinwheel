import { Component, ViewChild } from '@angular/core';
import { NgxWheelComponent, NgxWheelModule, TextAlignment, TextOrientation } from 'ngx-wheel'
import { CongradulationModalComponent } from '../congradulation-modal/congradulation-modal.component';
import { QuestionModalComponent } from '../question-modal/question-modal.component';
import { InstructionModalComponent } from '../instruction-modal/instruction-modal.component';
@Component({
    selector: 'app-spin-wheel',
    templateUrl: './spin-wheel.component.html',
    styleUrls: ['./spin-wheel.component.css']
})
export class SpinWheelComponent {
    @ViewChild(NgxWheelComponent, { static: false })
    wheel!: NgxWheelComponent;
    @ViewChild(InstructionModalComponent, { static: false })
    instruction!: InstructionModalComponent;
    @ViewChild(CongradulationModalComponent)
    congratulationModal!: CongradulationModalComponent;
    @ViewChild(QuestionModalComponent)
    questionModal!: QuestionModalComponent;
    classFlag: boolean = false;

    seed = [...Array(5).keys()]
    idToLandOn: any;
    items: any[] = [];
    textOrientation: TextOrientation = TextOrientation.HORIZONTAL
    textAlignment: TextAlignment = TextAlignment.OUTER
    Array = ['CMMI', 'DET', 'Lumina Leap', 'CBS', 'DevOps']

    ngOnInit() {
        this.idToLandOn = this.seed[Math.floor(Math.random() * this.seed.length)];
        const colors = ['#4EBEEB', '#8DE8AD', '#C981B2', '#FF9831', '#724BC3']
        this.items = this.seed.map((value) => ({
            fillStyle: colors[value],
            text: this.Array[value],
            id: value,
            textFillStyle: 'black',
            textFontSize: '18',
            textFontFamily: 'sans-serif'
        }))
    }
    reset() {
        this.idToLandOn = this.seed[Math.floor(Math.random() * this.seed.length)];
        this.wheel.reset();

    }
    spin() {
        this.wheel.spin()
    }
    okEvent(event: any) {
        this.instruction.closeModal();
        this.questionModal.openModal(this.idToLandOn + 1);
    }
    closeEventQuestion(event: any) {
        // this.instruction.openModal();
        // setTimeout(()=>{this.reset();},1000)
        this.reset();
    }
    after() {
        // this.congratulationModal.openModal(this.Array[this.idToLandOn]);
        this.questionModal.openModal(this.idToLandOn + 1);
    }
}